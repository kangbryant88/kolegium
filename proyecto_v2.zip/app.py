from flask import Flask, render_template, request, redirect, url_for, session, send_file, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import io
import os
import pandas as pd
import openpyxl
from docx import Document
from fpdf import FPDF

# Configuración de rutas para evitar errores en el servidor
basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.secret_key = 'clave_super_secreta_robo_enterprise'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'roboclass.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# ==========================================
# --- 1. MODELOS DE BASE DE DATOS ---
# ==========================================

class Rol(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), unique=True, nullable=False)
    permisos = db.Column(db.String(500), nullable=False, default="")
    usuarios = db.relationship('Usuario', backref='rol_info', lazy=True)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    nombre_completo = db.Column(db.String(100), nullable=False) 
    email = db.Column(db.String(120), unique=True, nullable=False)
    area_trabajo = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    rol_id = db.Column(db.Integer, db.ForeignKey('rol.id'), nullable=True)

class Anuncio(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100), nullable=False)
    mensaje = db.Column(db.Text, nullable=False)
    fecha = db.Column(db.DateTime, default=datetime.now)
    autor_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    autor = db.relationship('Usuario', backref='anuncios_creados')

class Bitacora(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.DateTime, default=datetime.now)
    grado = db.Column(db.String(50), nullable=False)
    actividad = db.Column(db.String(200), nullable=False)
    estado = db.Column(db.String(50), default='Completado')
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

class PlanificacionDefensoria(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tema_charla = db.Column(db.String(200), nullable=False)
    proposito = db.Column(db.Text, nullable=False)
    poblacion_objetivo = db.Column(db.String(100), nullable=False) 
    fecha_programada = db.Column(db.Date, nullable=False)
    hora_programada = db.Column(db.String(20), nullable=False)
    estado = db.Column(db.String(50), default='Pendiente')
    notas_seguimiento = db.Column(db.Text, nullable=True) 
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

class Grado(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    total_varones = db.Column(db.Integer, default=0)
    total_hembras = db.Column(db.Integer, default=0)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

class Tema(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

class AsistenciaDiaria(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.Date, nullable=False)
    grado_seccion = db.Column(db.String(100), nullable=False)
    matricula_total = db.Column(db.Integer, nullable=False)
    varones = db.Column(db.Integer, nullable=False, default=0)
    hembras = db.Column(db.Integer, nullable=False, default=0)
    asistentes = db.Column(db.Integer, nullable=False)
    porcentaje = db.Column(db.Float, nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

class AsistenciaPersonal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.Date, nullable=False)
    categoria = db.Column(db.String(50), nullable=False)
    matricula_base = db.Column(db.Integer, nullable=False, default=0)
    asistentes = db.Column(db.Integer, nullable=False, default=0)
    porcentaje = db.Column(db.Float)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

# ==========================================
# --- 2. INICIALIZACIÓN ---
# ==========================================

with app.app_context():
    # db.create_all()  # Desactivado: ahora se usa Flask-Migrate (Alembic)
    # Mapa maestro de permisos por rol
    PERMISOS_POR_ROL = {
        'Administrador Supremo': 'dashboard,planificador,asistencia,defensoria,configuracion,admin,anuncios',
        'Equipo Directivo': 'dashboard,asistencia,configuracion,admin,anuncios',
        'Docente de Aula': 'planificador,asistencia,anuncios',
        'Docente Especialista': 'planificador,asistencia,anuncios',
        'Defensoría Estudiantil': 'defensoria,anuncios',
    }

    if not Rol.query.first():
        for nombre, permisos in PERMISOS_POR_ROL.items():
            db.session.add(Rol(nombre=nombre, permisos=permisos))
        db.session.commit()
    else:
        # Migración: sincronizar permisos de roles existentes y crear faltantes
        for nombre, permisos in PERMISOS_POR_ROL.items():
            rol = Rol.query.filter_by(nombre=nombre).first()
            if rol:
                rol.permisos = permisos
            else:
                db.session.add(Rol(nombre=nombre, permisos=permisos))
        db.session.commit()

@app.context_processor
def inyectar_datos_globales():
    return dict(
        mis_permisos=session.get('permisos', ''),
        mi_rol=session.get('nombre_rol', 'Sin Rol'),
        total_anuncios=Anuncio.query.count(),
        hoy_str=datetime.now().strftime('%d/%m/%Y')
    )

# ==========================================
# --- 3. DASHBOARD Y AUTENTICACIÓN ---
# ==========================================

@app.route('/')
def index():
    if not session.get('logeado'): return redirect(url_for('login'))
    permisos = session.get('permisos', '')
    if 'dashboard' not in permisos:
        if 'planificador' in permisos: return redirect(url_for('planificador'))
        if 'defensoria' in permisos: return redirect(url_for('defensoria'))
        if 'asistencia' in permisos: return redirect(url_for('asistencia'))
        return redirect(url_for('en_espera'))

    ahora = datetime.now()
    dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
    meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    fecha_hoy_esp = f"{dias[ahora.weekday()]}, {ahora.day} de {meses[ahora.month-1]} de {ahora.year}"

    registros_hoy = AsistenciaDiaria.query.filter_by(fecha=ahora.date()).all()
    mat_hoy = sum(r.matricula_total for r in registros_hoy)
    asist_hoy = sum(r.asistentes for r in registros_hoy)
    porc_hoy = round((asist_hoy / mat_hoy) * 100, 1) if mat_hoy > 0 else 0.0

    registros_pers_hoy = AsistenciaPersonal.query.filter_by(fecha=ahora.date()).all()
    mat_pers_hoy = sum(r.matricula_base for r in registros_pers_hoy)
    asist_pers_hoy = sum(r.asistentes for r in registros_pers_hoy)
    porc_pers_hoy = round((asist_pers_hoy / mat_pers_hoy) * 100, 1) if mat_pers_hoy > 0 else 0.0
    
    desglose_personal = {'Docentes': 0, 'Administrativos': 0, 'Obreros': 0, 'Cocina': 0, 'Vigilantes': 0}
    for r in registros_pers_hoy:
        if r.categoria in desglose_personal: desglose_personal[r.categoria] += r.asistentes

    total_v = sum(g.total_varones for g in Grado.query.all())
    total_h = sum(g.total_hembras for g in Grado.query.all())
    ultimos_anuncios = Anuncio.query.order_by(Anuncio.fecha.desc()).limit(3).all()

    historico = AsistenciaDiaria.query.order_by(AsistenciaDiaria.fecha.desc()).limit(5).all()
    historico.reverse()
    labels_g = [h.fecha.strftime('%d/%m') for h in historico]
    datos_g = [h.porcentaje for h in historico]

    return render_template('index.html', fecha_full=fecha_hoy_esp, matricula_hoy=mat_hoy, 
                           asistentes_hoy=asist_hoy, porcentaje_hoy=porc_hoy,
                           total_v=total_v, total_h=total_h, anuncios=ultimos_anuncios,
                           labels_g=labels_g, datos_g=datos_g, mat_pers_hoy=mat_pers_hoy,
                           asist_pers_hoy=asist_pers_hoy, porc_pers_hoy=porc_pers_hoy,
                           desglose_personal=desglose_personal)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        u = Usuario.query.filter_by(username=request.form['username']).first()
        if u and check_password_hash(u.password, request.form['password']):
            session.update({
                'logeado': True, 'usuario_id': u.id, 'username': u.username, 
                'nombre_completo': u.nombre_completo, 'area_trabajo': u.area_trabajo
            })
            if u.rol_info:
                session['permisos'], session['nombre_rol'] = u.rol_info.permisos, u.rol_info.nombre
                return redirect(url_for('index'))
            session['permisos'], session['nombre_rol'] = '', 'En Espera'
            return redirect(url_for('en_espera'))
        return render_template('login.html', error='Credenciales incorrectas.')
    return render_template('login.html')

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        u_name, e_mail = request.form['username'], request.form['email']
        if Usuario.query.filter((Usuario.username == u_name) | (Usuario.email == e_mail)).first():
            return render_template('registro.html', error="El usuario o el correo ya están registrados.")
        nuevo = Usuario(nombre_completo=request.form['nombre_completo'], username=u_name, email=e_mail,
                        area_trabajo=request.form['area_trabajo'],
                        password=generate_password_hash(request.form['password'], method='pbkdf2:sha256'))
        db.session.add(nuevo); db.session.commit()
        if Usuario.query.count() == 1:
            nuevo.rol_id = Rol.query.filter_by(nombre='Administrador Supremo').first().id
            db.session.commit()
        return redirect(url_for('login'))
    return render_template('registro.html')

@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('login'))

@app.route('/en_espera')
def en_espera():
    return render_template('espera.html')

# ==========================================
# --- 4. PLANIFICADOR DOCENTE ---
# ==========================================

@app.route('/planificador')
def planificador():
    if not session.get('logeado'): return redirect(url_for('login'))
    uid = session['usuario_id']
    clases = Bitacora.query.filter_by(usuario_id=uid).order_by(Bitacora.fecha.desc()).all()
    grados = Grado.query.all(); temas = Tema.query.all()
    return render_template('planificador.html', registros=clases, grados=grados, temas=temas,
                           total=len(clases), completadas=len([c for c in clases if c.estado == 'Completado']),
                           pendientes=len([c for c in clases if c.estado == 'Pendiente']))

@app.route('/agregar', methods=['POST'])
def agregar():
    hora = request.form.get('hora', '07:00')
    f = datetime.strptime(f"{datetime.now().strftime('%Y-%m-%d')} {hora}", "%Y-%m-%d %H:%M")
    db.session.add(Bitacora(fecha=f, grado=request.form['grado'], actividad=request.form['actividad'], 
                            estado=request.form['estado'], usuario_id=session['usuario_id']))
    db.session.commit(); return redirect(url_for('planificador'))

@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    reg = Bitacora.query.get_or_404(id)
    if request.method == 'POST':
        reg.grado, reg.actividad, reg.estado = request.form['grado'], request.form['actividad'], request.form['estado']
        reg.fecha = datetime.strptime(f"{reg.fecha.strftime('%Y-%m-%d')} {request.form['hora']}", "%Y-%m-%d %H:%M")
        db.session.commit(); return redirect(url_for('planificador'))
    return render_template('editar.html', registro=reg, grados=Grado.query.all())

@app.route('/eliminar/<int:id>')
def eliminar(id):
    db.session.delete(Bitacora.query.get_or_404(id)); db.session.commit()
    return redirect(url_for('planificador'))

@app.route('/reporte_diario')
def reporte_diario():
    if not session.get('logeado'): return redirect(url_for('login'))
    hoy = datetime.now().date()
    regs = [r for r in Bitacora.query.filter_by(usuario_id=session['usuario_id']).all() if r.fecha.date() == hoy]
    return render_template('reporte.html', registros=regs)

@app.route('/reporte_general')
def reporte_general():
    if not session.get('logeado'): return redirect(url_for('login'))
    regs = Bitacora.query.filter_by(usuario_id=session['usuario_id']).order_by(Bitacora.fecha.desc()).all()
    return render_template('reporte.html', registros=regs)

# ==========================================
# --- 5. EXPORTACIONES (EXCEL / WORD) ---
# ==========================================

@app.route('/exportar_excel')
def exportar_excel():
    regs = Bitacora.query.filter_by(usuario_id=session['usuario_id']).all()
    datos = [{'Fecha': r.fecha.strftime('%d/%m/%Y'), 'Hora': r.fecha.strftime('%I:%M %p'), 
              'Grado': r.grado, 'Actividad': r.actividad, 'Estado': r.estado} for r in regs]
    df = pd.DataFrame(datos); output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Reporte', startrow=4, index=False)
        ws = writer.sheets['Reporte']; fmt = writer.book.add_format({'bold': True, 'font_size': 14})
        ws.write('A1', 'REPORTE DE ACTIVIDADES - EDUPALNNER OS', fmt)
        ws.write('A2', f"Docente: {session.get('nombre_completo')}")
        ws.write('A3', f"Área: {session.get('area_trabajo')}")
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
                     download_name="Reporte_EduPlanner.xlsx", as_attachment=True)

@app.route('/exportar_word')
def exportar_word():
    doc = Document(); doc.add_heading('REPORTE OFICIAL DE ACTIVIDADES', 0)
    p = doc.add_paragraph(); p.add_run('Docente: ').bold = True; p.add_run(f"{session.get('nombre_completo')}\n")
    p.add_run('Área: ').bold = True; p.add_run(f"{session.get('area_trabajo')}")
    table = doc.add_table(rows=1, cols=5); table.style = 'Table Grid'
    for i, t in enumerate(['Fecha', 'Hora', 'Grado', 'Actividad', 'Estado']): table.rows[0].cells[i].text = t
    for r in Bitacora.query.filter_by(usuario_id=session['usuario_id']).all():
        row = table.add_row().cells
        row[0].text, row[1].text = r.fecha.strftime('%d/%m/%Y'), r.fecha.strftime('%I:%M %p')
        row[2].text, row[3].text, row[4].text = r.grado, r.actividad, r.estado
    f = io.BytesIO(); doc.save(f); f.seek(0)
    return send_file(f, mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
                     download_name="Reporte_EduPlanner.docx", as_attachment=True)

# ==========================================
# --- 6. DEFENSORÍA ESTUDIANTIL ---
# ==========================================

@app.route('/defensoria', methods=['GET', 'POST'])
def defensoria():
    if not session.get('logeado'): return redirect(url_for('login'))
    if request.method == 'POST':
        db.session.add(PlanificacionDefensoria(
            tema_charla=request.form['tema_charla'], proposito=request.form['proposito'],
            poblacion_objetivo=request.form['poblacion_objetivo'], usuario_id=session['usuario_id'],
            fecha_programada=datetime.strptime(request.form['fecha_programada'], '%Y-%m-%d').date(), 
            hora_programada=request.form['hora_programada']
        ))
        db.session.commit(); return redirect(url_for('defensoria'))
    planes = PlanificacionDefensoria.query.filter_by(usuario_id=session['usuario_id']).all()
    return render_template('defensoria.html', planificaciones=planes)

@app.route('/editar_defensoria/<int:id>', methods=['POST'])
def editar_defensoria(id):
    reg = PlanificacionDefensoria.query.get_or_404(id)
    reg.tema_charla, reg.proposito, reg.poblacion_objetivo = request.form['tema_charla'], request.form['proposito'], request.form['poblacion_objetivo']
    db.session.commit(); return redirect(url_for('defensoria'))

@app.route('/eliminar_defensoria/<int:id>', methods=['POST'])
def eliminar_defensoria(id):
    db.session.delete(PlanificacionDefensoria.query.get_or_404(id)); db.session.commit()
    return redirect(url_for('defensoria'))

# --- EXPORTAR PDF DEFENSORÍA ---
@app.route('/exportar_pdf_defensoria')
def exportar_pdf_defensoria():
    if not session.get('logeado'): return redirect(url_for('login'))
    
    # Creamos el documento PDF
    pdf = FPDF()
    pdf.add_page()
    
    # Título del Documento
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, txt="Cronograma de Defensoria Estudiantil", ln=True, align='C')
    pdf.set_font("Arial", 'I', 12)
    pdf.cell(200, 10, txt=f"Docente: {session.get('nombre_completo')}", ln=True, align='C')
    pdf.ln(10)
    
    # Encabezados de la tabla
    pdf.set_font("Arial", 'B', 10)
    pdf.cell(25, 10, 'Fecha', 1, 0, 'C')
    pdf.cell(25, 10, 'Hora', 1, 0, 'C')
    pdf.cell(40, 10, 'Grado/Seccion', 1, 0, 'C')
    pdf.cell(50, 10, 'Tema de Charla', 1, 0, 'C')
    pdf.cell(50, 10, 'Proposito', 1, 1, 'C')
    
    # Consultamos los datos del usuario activo
    planes = PlanificacionDefensoria.query.filter_by(usuario_id=session['usuario_id']).order_by(PlanificacionDefensoria.fecha_programada.asc()).all()
    
    # Llenamos la tabla
    pdf.set_font("Arial", '', 9)
    for p in planes:
        # Acortamos los textos si son muy largos para que no rompan la tabla
        tema = (p.tema_charla[:25] + '...') if len(p.tema_charla) > 25 else p.tema_charla
        proposito = (p.proposito[:25] + '...') if len(p.proposito) > 25 else p.proposito
        
        pdf.cell(25, 10, p.fecha_programada.strftime('%d/%m/%Y'), 1)
        pdf.cell(25, 10, p.hora_programada, 1)
        pdf.cell(40, 10, p.poblacion_objetivo, 1)
        pdf.cell(50, 10, tema, 1)
        pdf.cell(50, 10, proposito, 1)
        pdf.ln()
        
    # Preparamos la descarga
    response = make_response(pdf.output(dest='S').encode('latin-1'))
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=Cronograma_Defensoria.pdf'
    return response    

# --- CARGA MASIVA EXCEL ---
@app.route('/descargar_plantilla')
def descargar_plantilla():
    output = io.BytesIO(); wb = openpyxl.Workbook(); ws = wb.active
    ws.append(['TEMA_CHARLA', 'PROPOSITO_OBJETIVO']); wb.save(output); output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
                     as_attachment=True, download_name='Plantilla_Defensoria.xlsx')

@app.route('/subir_plan', methods=['POST'])
def subir_plan():
    archivo = request.files.get('archivo_plan')
    if not archivo: return redirect(url_for('defensoria'))
    wb = openpyxl.load_workbook(archivo); ws = wb.active
    extraidas = [{'tema': str(r[0]).strip(), 'proposito': str(r[1]).strip()} for r in ws.iter_rows(min_row=2, values_only=True) if r[0] and r[1]]
    return render_template('asignar_masivo.html', charlas=extraidas)

@app.route('/guardar_masivo', methods=['POST'])
def guardar_masivo():
    temas, propositos, grados, fechas, horas = request.form.getlist('tema[]'), request.form.getlist('proposito[]'), request.form.getlist('grado[]'), request.form.getlist('fecha[]'), request.form.getlist('hora[]')
    for i in range(len(temas)):
        if grados[i] and fechas[i] and horas[i]:
            db.session.add(PlanificacionDefensoria(tema_charla=temas[i], proposito=propositos[i], poblacion_objetivo=grados[i], 
                                                  fecha_programada=datetime.strptime(fechas[i], '%Y-%m-%d').date(), 
                                                  hora_programada=horas[i], usuario_id=session['usuario_id']))
    db.session.commit(); return redirect(url_for('defensoria'))

# ==========================================
# --- 7. CONTROL DE ASISTENCIA ---
# ==========================================

@app.route('/asistencia', methods=['GET', 'POST'])
def asistencia():
    if not session.get('logeado'): return redirect(url_for('login'))
    if request.method == 'POST':
        grado = Grado.query.get(request.form['grado_id'])
        v, h = int(request.form['varones'] or 0), int(request.form['hembras'] or 0)
        t = grado.total_varones + grado.total_hembras
        p = round(((v + h) / t) * 100, 1) if t > 0 else 0
        db.session.add(AsistenciaDiaria(fecha=datetime.strptime(request.form['fecha'], '%Y-%m-%d').date(), 
                       grado_seccion=grado.nombre, matricula_total=t, varones=v, hembras=h, asistentes=v+h, 
                       porcentaje=p, usuario_id=session['usuario_id']))
        db.session.commit(); return redirect(url_for('asistencia'))
    regs = AsistenciaDiaria.query.filter_by(usuario_id=session['usuario_id']).order_by(AsistenciaDiaria.fecha.desc()).all()
    return render_template('asistencia.html', registros=regs, grados=Grado.query.all(), hoy=datetime.now().strftime('%Y-%m-%d'))

@app.route('/eliminar_asistencia/<int:id>', methods=['POST'])
def eliminar_asistencia(id):
    db.session.delete(AsistenciaDiaria.query.get_or_404(id)); db.session.commit()
    return redirect(url_for('asistencia'))

@app.route('/asistencia_personal', methods=['GET', 'POST'])
def asistencia_personal():
    if not session.get('logeado'): return redirect(url_for('login'))
    if request.method == 'POST':
        mat_base = int(request.form.get('matricula_base') or 0)
        asistentes = int(request.form.get('asistentes') or 0)
        pct = round((asistentes / mat_base) * 100, 1) if mat_base > 0 else 0.0
        db.session.add(AsistenciaPersonal(
            fecha=datetime.strptime(request.form['fecha'], '%Y-%m-%d').date(), 
            categoria=request.form['categoria'], 
            matricula_base=mat_base, 
            asistentes=asistentes, 
            porcentaje=pct, 
            usuario_id=session['usuario_id']
        ))
        db.session.commit()
        return redirect(url_for('asistencia_personal'))
    regs = AsistenciaPersonal.query.filter_by(usuario_id=session['usuario_id']).order_by(AsistenciaPersonal.fecha.desc()).all()
    
    # Memoria: Obtener el último valor registrado por categoría
    bases_conocidas = {}
    categorias = ['Docentes', 'Administrativos', 'Obreros', 'Vigilantes', 'Cocina']
    for cat in categorias:
        ultimo = AsistenciaPersonal.query.filter_by(usuario_id=session['usuario_id'], categoria=cat)\
            .order_by(AsistenciaPersonal.fecha.desc(), AsistenciaPersonal.id.desc()).first()
        if ultimo:
            bases_conocidas[cat] = ultimo.matricula_base

    return render_template('asistencia_personal.html', registros=regs, hoy=datetime.now().strftime('%Y-%m-%d'), bases=bases_conocidas)

@app.route('/eliminar_asistencia_personal/<int:id>')
def eliminar_asistencia_personal(id):
    if not session.get('logeado'): return redirect(url_for('login'))
    db.session.delete(AsistenciaPersonal.query.get_or_404(id))
    db.session.commit()
    return redirect(url_for('asistencia_personal'))

@app.route('/editar_asistencia_personal/<int:id>', methods=['GET', 'POST'])
def editar_asistencia_personal(id):
    if not session.get('logeado'): return redirect(url_for('login'))
    reg = AsistenciaPersonal.query.get_or_404(id)
    if request.method == 'POST':
        mat_base = int(request.form.get('matricula_base') or 0)
        asistentes = int(request.form.get('asistentes') or 0)
        
        reg.fecha = datetime.strptime(request.form['fecha'], '%Y-%m-%d').date()
        reg.categoria = request.form['categoria']
        reg.matricula_base = mat_base
        reg.asistentes = asistentes
        reg.porcentaje = round((asistentes / mat_base) * 100, 1) if mat_base > 0 else 0.0
        
        db.session.commit()
        return redirect(url_for('asistencia_personal'))
    
    return render_template('editar_asistencia_personal.html', registro=reg)

# ==========================================
# --- 8. CONFIGURACIONES GLOBALES ---
# ==========================================

@app.route('/configuracion', methods=['GET', 'POST'])
def configuracion():
    if not session.get('logeado'): return redirect(url_for('login'))
    if request.method == 'POST':
        if 'nuevo_grado' in request.form:
            db.session.add(Grado(nombre=request.form['nuevo_grado'], 
                                 total_varones=int(request.form.get('m_varones') or 0),
                                 total_hembras=int(request.form.get('m_hembras') or 0), 
                                 usuario_id=session['usuario_id']))
        if 'nuevo_tema' in request.form:
            db.session.add(Tema(nombre=request.form['nuevo_tema'], usuario_id=session['usuario_id']))
        db.session.commit(); return redirect(url_for('configuracion'))
    return render_template('configuracion.html', grados=Grado.query.all(), temas=Tema.query.all())

@app.route('/editar_grado/<int:id>', methods=['POST'])
def editar_grado(id):
    g = Grado.query.get_or_404(id)
    g.total_varones, g.total_hembras = int(request.form.get('m_varones', 0)), int(request.form.get('m_hembras', 0))
    db.session.commit(); return redirect(url_for('configuracion'))

@app.route('/borrar_grado/<int:id>')
def borrar_grado(id):
    db.session.delete(Grado.query.get_or_404(id)); db.session.commit()
    return redirect(url_for('configuracion'))

@app.route('/borrar_tema/<int:id>')
def borrar_tema(id):
    db.session.delete(Tema.query.get_or_404(id)); db.session.commit()
    return redirect(url_for('configuracion'))

# ==========================================
# --- 9. ADMIN Y ANUNCIOS ---
# ==========================================

@app.route('/admin_usuarios')
def admin_usuarios():
    if 'admin' not in session.get('permisos', ''): return "🚫 No autorizado."
    return render_template('admin.html', usuarios=Usuario.query.all(), roles=Rol.query.all())

@app.route('/cambiar_rol/<int:usuario_id>', methods=['POST'])
def cambiar_rol(usuario_id):
    if 'admin' not in session.get('permisos', ''):
        return '🚫 No autorizado.', 403
    nuevo_rol = request.form.get('nuevo_rol', '').strip()
    if not nuevo_rol:
        return redirect(url_for('admin_usuarios'))
    rol = Rol.query.get(int(nuevo_rol))
    if not rol:
        return redirect(url_for('admin_usuarios'))
    usuario = Usuario.query.get_or_404(usuario_id)
    if usuario.id == 1:
        return redirect(url_for('admin_usuarios'))
    usuario.rol_id = rol.id
    db.session.commit()
    return redirect(url_for('admin_usuarios'))

@app.route('/eliminar_usuario/<int:id>', methods=['POST'])
def eliminar_usuario(id):
    if 'admin' not in session.get('permisos', ''):
        return '🚫 No autorizado.', 403
    if id != session['usuario_id']:
        usuario = Usuario.query.get_or_404(id)
        if usuario.id == 1:
            return redirect(url_for('admin_usuarios'))
        db.session.delete(usuario)
        db.session.commit()
    return redirect(url_for('admin_usuarios'))

@app.route('/anuncios', methods=['GET', 'POST'])
def anuncios():
    if not session.get('logeado'): return redirect(url_for('login'))
    if request.method == 'POST' and 'anuncios' in session.get('permisos', ''):
        db.session.add(Anuncio(titulo=request.form['titulo'], mensaje=request.form['mensaje'], autor_id=session['usuario_id']))
        db.session.commit(); return redirect(url_for('anuncios'))
    return render_template('anuncios.html', anuncios=Anuncio.query.order_by(Anuncio.fecha.desc()).all())

@app.route('/eliminar_anuncio/<int:id>', methods=['POST'])
def eliminar_anuncio(id):
    if 'admin' in session.get('permisos', ''):
        db.session.delete(Anuncio.query.get(id)); db.session.commit()
    return redirect(url_for('anuncios'))

if __name__ == '__main__':
    app.run(debug=True)